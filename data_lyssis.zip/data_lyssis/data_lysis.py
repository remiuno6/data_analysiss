import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 1. Loading the dataframe using pandas and displaying the first 5 rows
file_path = '/mnt/data/IRIS.csv'
df = pd.read_csv(file_path)
print(df.head())

# 2. Explore the structure of the dataset

df.info()
print(df.info())

# Check for missing values
missing_values = df.isnull().sum()
print(missing_values)

# Clean the dataframe by dropping missing values (if any)
df.dropna(inplace=True)

# 3. Compute basic statistics of numerical columns
statistics = df.describe()
print(statistics)

# 4. Perform groupings on a categorical column 
grouped_means = df.groupby('species').mean()
print(grouped_means)

# 5. Identify patterns or interesting findings by inspecting if petal length differs significantly across species
for species in df['species'].unique():
    print(f"Average petal length for {species}: {grouped_means.loc[species, 'petal_length']:.2f}")

# 6. Data Visualization

# Visualization 1: Line chart showing trends over a hypothetical index variable
plt.figure(figsize=(10, 6))
plt.plot(df.index, df['sepal_length'], label='Sepal Length', color='blue', alpha=0.7)
plt.plot(df.index, df['petal_length'], label='Petal Length', color='green', alpha=0.7)
plt.title('Trends in Sepal and Petal Lengths Over Time')
plt.xlabel('Index (as proxy for time)')
plt.ylabel('Length (cm)')
plt.legend()
plt.grid(alpha=0.3)
plt.show()

# Visualization 2: Bar chart showing average petal length per species
plt.figure(figsize=(8, 6))
grouped_means['petal_length'].plot(kind='bar', color=['blue', 'orange', 'green'], alpha=0.7)
plt.title('Average Petal Length by Species')
plt.xlabel('Species')
plt.ylabel('Petal Length (cm)')
plt.xticks(rotation=45)
plt.grid(alpha=0.3, axis='y')
plt.show()

# Visualization 3: Histogram of sepal width distribution
plt.figure(figsize=(8, 6))
sns.histplot(df['sepal_width'], kde=True, color='purple', bins=10, alpha=0.7)
plt.title('Distribution of Sepal Width')
plt.xlabel('Sepal Width (cm)')
plt.ylabel('Frequency')
plt.grid(alpha=0.3)
plt.show()

# Visualization 4: Scatter plot of petal length vs petal width
plt.figure(figsize=(8, 6))
sns.scatterplot(data=df, x='petal_length', y='petal_width', hue='species', palette='deep', alpha=0.7)
plt.title('Petal Length vs Petal Width by Species')
plt.xlabel('Petal Length (cm)')
plt.ylabel('Petal Width (cm)')
plt.legend(title='Species')
plt.grid(alpha=0.3)
plt.show()
